package com.example.studyapp_laila

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_row.view.*


class RVAdapter (val context: Context, val messages: ArrayList<ArrayList<String>>):
RecyclerView.Adapter<RVAdapter.MessageViewHolder>() {
    class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        return MessageViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.item_row,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.itemView.apply {
           TextView_title.text = messages[position][0]
            TextView_details.text = messages[position][1]
            Card_View.setOnClickListener{

                val dialogBuilder = AlertDialog.Builder(context)
                dialogBuilder.setMessage("Detailed notes here.")
                    .setPositiveButton("OK", DialogInterface.OnClickListener {
                            dialog, id -> dialog.cancel()
                    })

                val alert = dialogBuilder.create()
                alert.setTitle(messages[position][0] )
                alert.show()
            }
        }
    }

    override fun getItemCount()= messages.size

}