package com.example.studyapp_laila

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Android_Activity : AppCompatActivity() {

    lateinit var RecyclerView_kotlin_android: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.kotlin_android_activity)
        title = "Android Studio"

        val items = arrayListOf(
            arrayListOf("Project Setup", "Setting up an Android Studio Project."),
            arrayListOf("Console", "how print the console."),
            arrayListOf("UI Elements", "Creating, modifying, and initializing UI Elements.")
        )

        RecyclerView_kotlin_android = findViewById(R.id.RecyclerView_kotlin_android)
        RecyclerView_kotlin_android.adapter = RVAdapter(this, items)
        RecyclerView_kotlin_android.layoutManager = LinearLayoutManager(this)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.Back -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}