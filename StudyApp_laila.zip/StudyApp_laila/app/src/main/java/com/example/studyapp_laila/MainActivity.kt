package com.example.studyapp_laila

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button

class MainActivity : AppCompatActivity() {

    lateinit var Button_Kotlin: Button
    lateinit var Button_Android: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title ="Study of Android Studio & Kotlin"

        Button_Android = findViewById<Button>(R.id.Button_Android)
        Button_Kotlin = findViewById<Button>(R.id.Button_Kotlin)

        Button_Android.setOnClickListener {

            intent (Android_Activity())

        }

        Button_Kotlin.setOnClickListener {
            intent (kotlin_activity())
        }
    }

    private fun intent (activity: Activity){
        val intent = Intent(this, activity::class.java)
        startActivity(intent)
    }
}